import random
import pandas as pd

# 1. 定义你的野生型（WT）序列（必须与你 sh 文件中的 target_seq 完全一致）
WT_SEQ = "MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLVTTLSYGVQCFSRYPDHMKQHDFFKSAMPEGYVQERTIFFKDDGNYKTRAEVKFEGDTLVNRIELKGIDFKEDGNILGHKLEYNYNSHNVYIMADKQKNGIKVNFKIRHNIEDGSVQLADHYQQNTPIGDGPVLLPDNHYLSTQSALSKDPNEKRDHMVLLEFVTAAGITHGMDELYK"
AMINO_ACIDS = list("ACDEFGHIKLMNPQRSTVWY")

def generate_random_mutant(wt_seq, num_mutations=2):
    """在 WT 序列上随机挑选几个位置进行突变"""
    seq_list = list(wt_seq)
    # 随机选择不重复的突变位置
    positions = random.sample(range(len(wt_seq)), num_mutations)
    
    mutant_names = []
    for pos in positions:
        orig_aa = wt_seq[pos]
        # 确保突变后的氨基酸和原来不一样
        new_aa = random.choice([aa for aa in AMINO_ACIDS if aa != orig_aa])
        seq_list[pos] = new_aa
        # 记录生信标准的突变格式，例如 K3R (位置从1开始算)
        mutant_names.append(f"{orig_aa}{pos+1}{new_aa}")
    
    return ":".join(mutant_names), "".join(seq_list)

# 2. 设定你想生成的虚拟序列池大小（比如先生成 5000 条突变体）
POOL_SIZE = 5000
MUTATIONS_PER_SEQ = 3  # 每条序列包含 3 个随机点突变

pool_data = []
for _ in range(POOL_SIZE):
    mutant_name, mutant_seq = generate_random_mutant(WT_SEQ, num_mutations=MUTATIONS_PER_SEQ)
    pool_data.append({
        "mutant": mutant_name,
        "mutated_sequence": mutant_seq,
        "DMS_score": 0.0,       # 占位符，下游脚本硬编码需要
        "DMS_score_bin": 0      # 占位符
    })

# 3. 导出为没有经过任何模型污染的干净测试集
df_pool = pd.DataFrame(pool_data)
# 💡 核心：由于之前的教训，我们直接在内存里把验证需要的 train_test_split 列也帮它伪造好（全部设为 0）
df_pool['train_test_split'] = 0

df_pool.to_csv("proteinnpt_3_sequence_pool.csv", index=False)
print(f"成功生成包含 {POOL_SIZE} 条随机突变序列的候选池：protennpt_3_sequence_pool.csv")
