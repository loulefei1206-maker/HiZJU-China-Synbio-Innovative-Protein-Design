import pandas as pd

print("正在读取并修剪数据...")

# 1. 处理真实实验数据 (老表)
df_real = pd.read_csv("avGFP_ready_data.csv")
# 只保留这三个最核心的列，无视原有的 fold_random_5 等额外信息
df_real = df_real[['mutant', 'mutated_sequence', 'DMS_score']].copy()
# 强制打上标签：0 代表这是让模型复习用的真实训练集
df_real['custom_fold'] = 0  

# 2. 处理虚拟生成的序列 (新表)
df_virtual = pd.read_csv("proteinnpt_3_sequence_pool.csv")
# 同样只保留核心列，把多余的 DMS_score_bin 和 train_test_split 全部扔掉
df_virtual = df_virtual[['mutant', 'mutated_sequence', 'DMS_score']].copy()
# 强制打上标签：1 代表这是需要模型去盲猜打分的测试集
df_virtual['custom_fold'] = 1  

# 3. 完美上下拼接
df_combined = pd.concat([df_real, df_virtual], ignore_index=True)

# 4. 导出为终极大表
df_combined.to_csv("avGFP_combined_for_inference.csv", index=False)

print(f"拼表完美成功！")
print(f"真实参考数据：{len(df_real)} 条")
print(f"待打分新数据：{len(df_virtual)} 条")
print(f"终极大表总计：{len(df_combined)} 条，已保存为 avGFP_combined_for_inference.csv")