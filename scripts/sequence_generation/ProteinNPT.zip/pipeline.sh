#!/bin/bash  
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --time=100-00:00:00
#SBATCH --job-name=ProteinNPT

date

export CUDA_VISIBLE_DEVICES=1
source config.sh
source /opt/anaconda3/etc/profile.d/conda.sh
conda activate proteinnpt

export assay_data_location="../avGFP_combined_for_inference.csv"
export MSA_location="../avGFP_alignment.a2m"
export target_seq="MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLVTTLSYGVQCFSRYPDHMKQHDFFKSAMPEGYVQERTIFFKDDGNYKTRAEVKFEGDTLVNRIELKGIDFKEDGNILGHKLEYNYNSHNVYIMADKQKNGIKVNFKIRHNIEDGSVQLADHYQQNTPIGDGPVLLPDNHYLSTQSALSKDPNEKRDHMVLLEFVTAAGITHGMDELYK"

python pipeline.py \
    --proteinnpt_data_location ../my_weights \
    --assay_data_location ${assay_data_location} \
    --MSA_location ${MSA_location} \
    --target_seq ${target_seq} \
    --fold_variable_name custom_fold \
    --test_fold_index 1 \
    --embeddings_MSAT_num_MSA_sequences 29 \
    --model_config_location ../proteinnpt/proteinnpt/model_configs/PNPT_final.json
